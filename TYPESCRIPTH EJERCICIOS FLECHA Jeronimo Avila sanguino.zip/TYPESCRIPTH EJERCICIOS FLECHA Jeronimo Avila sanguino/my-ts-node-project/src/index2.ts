function factorialPasoAPaso(num: number): number | string {
    if (num < 0) {
        return "El número debe ser positivo.";
    }

    if (num === 0) {
        return 1;
    }

    let resultado = 1;

    for (let i = 1; i <= num; i++) {
        resultado *= i;
        console.log(`Paso ${i}: Multiplicando ${resultado / i} × ${i} = ${resultado}`);
    }

    return resultado;
}

console.log("Resultado final:", factorialPasoAPaso(2));
console.log("Resultado final:", factorialPasoAPaso(3));
console.log("Resultado final:", factorialPasoAPaso(4));
