
type EstadoComanda = 'pendiente' | 'en preparacion' | 'lista' | 'entregada';

interface Plato {
    id: number;
    nombre: string;
    precio: number;
}

interface Comanda {
    id: number;
    mesa: number;
    estado: EstadoComanda;
    platos: Plato[];
    fechaHora: Date;
}


const comandas: Comanda[] = [
    {
        id: 1,
        mesa: 1,
        estado: 'pendiente',
        platos: [
            { id: 1, nombre: 'Hamburguesa', precio: 80 },
            { id: 2, nombre: 'Papas Fritas', precio: 30 }
        ],
        fechaHora: new Date('2025-05-15T13:15:00')
    },
    {
        id: 2,
        mesa: 2,
        estado: 'en preparacion',
        platos: [
            { id: 3, nombre: 'Pizza', precio: 100 }
        ],
        fechaHora: new Date('2025-05-15T14:00:00')
    },
    {
        id: 3,
        mesa: 1,
        estado: 'entregada',
        platos: [
            { id: 1, nombre: 'Hamburguesa', precio: 80 },
            { id: 4, nombre: 'Coca-Cola', precio: 20 }
        ],
        fechaHora: new Date('2025-05-15T15:00:00')
    },
    {
        id: 4,
        mesa: 3,
        estado: 'lista',
        platos: [
            { id: 5, nombre: 'Ensalada', precio: 50 }
        ],
        fechaHora: new Date('2025-05-15T13:45:00')
    }
];


function filtrarPorEstado(comandas: Comanda[], estado: EstadoComanda): Comanda[] {
    return comandas.filter(comanda => comanda.estado === estado);
}


function calucularTotalPorMesa(comandas: Comanda[], mesa: number): number {
    return comandas
        .filter(comanda => comanda.mesa === mesa)
        .flatMap(comanda => comanda.platos)
        .reduce((total, plato) => total + plato.precio, 0);
}


interface ComandaCocina {
    mesa: number;
    platos: string[];
    hora: string;
}

function transformarParaCocina(comandas: Comanda[]): ComandaCocina[] {
    return comandas.map(comanda => ({
        mesa: comanda.mesa,
        platos: comanda.platos.map(plato => plato.nombre),
        hora: comanda.fechaHora.toLocaleTimeString()
    }));
}


function obtenerPlatosMasVendidos(comandas: Comanda[], inicio: Date, fin: Date): Map<string, number> {
    const contador = new Map<string, number>();

    comandas
        .filter(c => c.fechaHora >= inicio && c.fechaHora <= fin)
        .flatMap(c => c.platos)
        .forEach(plato => {
            const cantidad = contador.get(plato.nombre) ?? 0;
            contador.set(plato.nombre, cantidad + 1);
        });

    return contador;
}


function agruparPorHora(comandas: Comanda[]): Map<number, Comanda[]> {
    const agrupadas = new Map<number, Comanda[]>();

    for (const comanda of comandas) {
        const hora = comanda.fechaHora.getHours();
        const existentes = agrupadas.get(hora) ?? [];
        existentes.push(comanda);
        agrupadas.set(hora, existentes);
    }

    return agrupadas;
}


console.log('--- Comandas PENDIENTES ---');
console.log(filtrarPorEstado(comandas, 'pendiente'));

console.log('--- Total por mesa 1 ---');
console.log(calucularTotalPorMesa(comandas, 1));

console.log('--- Comandas para cocina ---');
console.log(transformarParaCocina(comandas));

console.log('--- Platos más vendidos entre 13:00 y 15:00 ---');
console.log(obtenerPlatosMasVendidos(comandas, new Date('2025-05-15T13:00:00'), new Date('2025-05-15T15:00:00')));

console.log('--- Comandas agrupadas por hora ---');
console.log(agruparPorHora(comandas));
