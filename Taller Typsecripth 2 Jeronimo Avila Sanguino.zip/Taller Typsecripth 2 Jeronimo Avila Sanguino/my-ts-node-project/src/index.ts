class Paciente {
    constructor(public id: number, public nombre: string) {}
}
class Medico {
    constructor(
        public id: number,
        public nombre: string,
        public especialidad: string
    ) {}
}

class Cita {
    constructor(
        public idPaciente: number,
        public idMedico: number,
        public fecha: string,
        public hora: string
    ){}
}

const pacientes: Paciente[] = [
    new Paciente(1, "Ana Gomez"),
    new Paciente(2, "Luis Perez")
];


const medicos: Medico[] = [
   new Medico(1, "Dra. Marta Ruiz", "Cardiología"),
   new Medico(2, "Dr. Juan Torres" , "Dermatologia")
];

const citas: Cita[] = [
    new Cita(1, 1, "2015-05-12", "10:00"),
    new Cita(2, 2, "2025-05-12", "11:00"),
    new Cita(2, 2, "2025-05-12", "09:00"),
]

function filtrarCitasPorEspecialidad(especialidad: string): Cita[] {
    return citas.filter(cita => {
        const medico = medicos.find(m => m.id === cita.idMedico);
        return medico?.especialidad === especialidad
    })
}

function obtenerCitasDePaciente(idPaciente: number): Cita[] {
    return citas.filter(cita => cita.idPaciente === idPaciente);
}

function listarCitasPorFecha(fecha: string): Cita[] {
    return citas.filter(citas => citas.fecha === fecha);
}

function generarReporteDiario(fecha: string): any[] {
    const citasDelDia = listarCitasPorFecha(fecha);

    return citasDelDia.map(cita => {
        const paciente = pacientes.find(p => p.id === cita.idPaciente);
        const medico = medicos.find(m => m.id === cita.idMedico);

        return {
            hora: cita.hora,
            paciente: paciente?.nombre || "Desconocido",
            medico: medico?.nombre || "Desconocida"
        };
    });
}

function verificarDisponibilidad(idMedico: number, fecha: string, hora: string): boolean {
    return !citas.some(cita => 
        cita.idMedico === idMedico &&
        cita.fecha === fecha &&
        cita.hora === hora

    );
}

console.log("Citas de cardiologia");
console.log(filtrarCitasPorEspecialidad("Cardiologia"));

console.log("Citas del paciente con ID 1:");
console.log(obtenerCitasDePaciente(1));

console.log("Citas para el 12 de mayo de 2025");
console.log(listarCitasPorFecha("2025-05-12"));

console.log("Reporte diario del 12 de mayo");
console.log(generarReporteDiario("2025-05-12"));

console.log("¿El Dr. 1 esta disponible el 12/05/2025 a las 10:00?");
console.log(verificarDisponibilidad(1, "2025-05-12", "10:00") ? "Si" : "No");