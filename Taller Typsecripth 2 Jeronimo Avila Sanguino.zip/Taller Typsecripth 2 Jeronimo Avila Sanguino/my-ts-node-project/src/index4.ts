// 1. Interfaces para definir la estructura de los datos
interface Equipo {
  id: number;
  nombre: string;
  tipo: string;
  valor: number;
  aulaId: number | null; // null si no está asignado
}

interface Aula {
  id: number;
  nombre: string;
}

// 2. Datos simulados (equipos y aulas)
const equipos: Equipo[] = [
  { id: 1, nombre: "Laptop HP", tipo: "laptop", valor: 800, aulaId: 1 },
  { id: 2, nombre: "Proyector Epson", tipo: "proyector", valor: 500, aulaId: 2 },
  { id: 3, nombre: "Tablet Samsung", tipo: "tablet", valor: 300, aulaId: null },
  { id: 4, nombre: "Proyector LG", tipo: "proyector", valor: 400, aulaId: 1 },
  { id: 5, nombre: "PC Dell", tipo: "pc", valor: 1000, aulaId: 3 },
  { id: 6, nombre: "Monitor Samsung", tipo: "monitor", valor: 200, aulaId: null }
];

const aulas: Aula[] = [
  { id: 1, nombre: "Aula A" },
  { id: 2, nombre: "Aula B" },
  { id: 3, nombre: "Aula C" },
  { id: 4, nombre: "Aula D" }
];

// 3. Función para obtener equipos no asignados a ninguna aula
function filtrarEquiposDisponibles(): Equipo[] {
  return equipos.filter(equipo => equipo.aulaId === null);
}

// 4. Función para obtener todos los equipos asignados a un aula específica
function obtenerEquiposPorAula(aulaId: number): Equipo[] {
  return equipos.filter(equipo => equipo.aulaId === aulaId);
}

// 5. Función para transformar los datos de los equipos en un inventario textual
function generarInventario(): string[] {
  return equipos.map(e => `ID:${e.id} - ${e.nombre} (${e.tipo}) - Valor: $${e.valor}`);
}

// 6. Función para verificar qué aulas no tienen un proyector asignado
function aulasSinProyector(): Aula[] {
  return aulas.filter(aula => {
    const tieneProyector = equipos.some(
      eq => eq.aulaId === aula.id && eq.tipo.toLowerCase() === "proyector"
    );
    return !tieneProyector;
  });
}

// 7. Función para calcular el valor total de equipos asignados por aula
function valorTotalPorAula(): { [nombreAula: string]: number } {
  const resultado: { [nombreAula: string]: number } = {};
  
  for (const aula of aulas) {
    const total = equipos
      .filter(equipo => equipo.aulaId === aula.id)
      .reduce((suma, equipo) => suma + equipo.valor, 0);
    
    resultado[aula.nombre] = total;
  }

  return resultado;
}

// 8. Ejecutar las funciones y mostrar los resultados
console.log("1. Equipos disponibles:");
console.log(filtrarEquiposDisponibles());

console.log("\n2. Equipos en Aula 1:");
console.log(obtenerEquiposPorAula(1));

console.log("\n3. Inventario:");
console.log(generarInventario());

console.log("\n4. Aulas sin proyector:");
console.log(aulasSinProyector());

console.log("\n5. Valor total por aula:");
console.log(valorTotalPorAula());
