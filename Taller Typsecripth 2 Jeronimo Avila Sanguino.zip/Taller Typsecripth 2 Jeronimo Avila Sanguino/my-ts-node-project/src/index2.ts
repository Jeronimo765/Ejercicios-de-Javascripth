type Categoria = 'Conferencia' | 'Seminario' | 'Taller';

interface Evento {
  id: number;
  nombre: string;
  categoria: Categoria;
  fecha: string; // formato ISO: 'YYYY-MM-DD'
  cupoMaximo: number;
  participantes: Participante[];
}

interface Participante {
  id: number;
  nombre: string;
  correo: string;
  asistio: boolean;
}

// Datos de ejemplo
let eventos: Evento[] = [
  {
    id: 1,
    nombre: 'Conferencia de Tecnología',
    categoria: 'Conferencia',
    fecha: '2025-06-01',
    cupoMaximo: 100,
    participantes: [
      { id: 1, nombre: 'Juan Pérez', correo: 'juan@example.com', asistio: true },
      { id: 2, nombre: 'Ana Gómez', correo: 'ana@example.com', asistio: false },
    ],
  },
  {
    id: 2,
    nombre: 'Taller de Desarrollo Web',
    categoria: 'Taller',
    fecha: '2025-06-15',
    cupoMaximo: 30,
    participantes: [
      { id: 3, nombre: 'Luis Torres', correo: 'luis@example.com', asistio: true },
    ],
  },
];

// 1. Filtrar eventos por fecha o categoría
function filtrarEventos(fecha?: string, categoria?: Categoria): Evento[] {
  return eventos.filter(evento => {
    const porFecha = fecha ? evento.fecha === fecha : true;
    const porCategoria = categoria ? evento.categoria === categoria : true;
    return porFecha && porCategoria;
  });
}

// 2. Obtener lista de participantes de un evento
function obtenerParticipantes(eventoId: number): Participante[] {
  const evento = eventos.find(e => e.id === eventoId);
  return evento ? evento.participantes : [];
}

// 3. Verificar disponibilidad de cupos
function verificarCuposDisponibles(eventoId: number): boolean {
  const evento = eventos.find(e => e.id === eventoId);
  if (!evento) return false;
  return evento.participantes.length < evento.cupoMaximo;
}

// 4. Transformar inscripciones para certificados
function generarCertificados(eventoId: number): string[] {
  const evento = eventos.find(e => e.id === eventoId);
  if (!evento) return [];
  return evento.participantes
    .filter(p => p.asistio)
    .map(p => `Certificado de participación para ${p.nombre} en ${evento.nombre}`);
}

// 5. Calcular estadísticas de asistencia por tipo de evento
function estadisticasAsistencia(): Record<Categoria, { total: number; asistencias: number }> {
  const estadisticas: Record<Categoria, { total: number; asistencias: number }> = {
    Conferencia: { total: 0, asistencias: 0 },
    Seminario: { total: 0, asistencias: 0 },
    Taller: { total: 0, asistencias: 0 },
  };

  for (const evento of eventos) {
    const datos = estadisticas[evento.categoria];
    datos.total += evento.participantes.length;
    datos.asistencias += evento.participantes.filter(p => p.asistio).length;
  }

  return estadisticas;
}

// Ejemplo de uso
console.log('Eventos en junio:', filtrarEventos('2025-06-01'));
console.log('Participantes del evento 1:', obtenerParticipantes(1));
console.log('Cupos disponibles para evento 1:', verificarCuposDisponibles(1));
console.log('Certificados del evento 1:', generarCertificados(1));
console.log('Estadísticas de asistencia:', estadisticasAsistencia());
