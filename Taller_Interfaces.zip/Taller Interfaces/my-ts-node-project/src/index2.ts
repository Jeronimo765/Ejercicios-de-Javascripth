interface Product {
    id: number;
    name: string;
    price: number;
    description?:string;
}
interface Inventory {
    products: Product[];

    addProduct(product: Product): void;
    findProductByName(name: string): Product | undefined;
}
class StoreInventory implements Inventory {
    products: Product[] = [];

    addProduct(product: Product): void {
        this.products.push(product);
    }

    findProductByName(name: string): Product | undefined {
        return this.products.find(p => p.name.toLowerCase() === name.toLowerCase());
    }
}
const Inventory = new StoreInventory();

const product1: Product = {
    id: 1,
    name: "Laptop",
    price: 15000
};

const product2: Product = {
    id: 2,
    name: "Mouse",
    price: 25000,
    description: "Mouse inalambrico"
};

Inventory.addProduct(product1);
Inventory.addProduct(product2);

console.log("Inventario:", Inventory.products);

const found = Inventory.findProductByName("mouse");
console.log("Producto encontrado:", found);