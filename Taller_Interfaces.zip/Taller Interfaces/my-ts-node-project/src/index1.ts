interface User {
    id: number;
    name: string;
    email: string;
}
interface Admin extends User {
    role: string;
};
function printUserData(user: User): void {
    console.log(`ID: ${user.id}`);
    console.log(`NAME: ${user.name}`);
    console.log(`EMAIL: ${user.email}`);
}
const regularUser: User = {
    id: 1,
    name: "carlos",
    email: "carlosQexample.com"
};
const adminUser: Admin = {
    id: 2,
    name: "Lucia",
    email: "lucia@example.com",
    role: "SuperAdmin"
};
printUserData(regularUser);
printUserData(adminUser);