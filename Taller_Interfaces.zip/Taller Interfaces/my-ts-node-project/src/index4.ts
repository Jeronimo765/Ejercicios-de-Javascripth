import { findPackageJSON } from "module";

interface Database {
    connect(): void;
    find(table: string, id: number): void;
    update(table: string, id: number, data: object): void;
    disconnect(): void;
}
class MySQLDatabase implements Database {
    connect(): void {
        console.log("Conectando a MySQL...");
    }

    find(table: string, id: number): void {
        console.log(`Buscando en la tabla '${table}' el ID ${id} en MySQL`);
    }

    update(table: string, id: number, data: object): void {
        console.log(`Actualizando ID ${id} en la tabla '${table}' con los datos ${JSON.stringify(data)} en MySQL`);
    }

    disconnect(): void {
        console.log("Desconectando de MySQL...");
    }
}
class SQLiteDatabase implements Database {
  connect(): void {
    console.log("Conectando a SQLite...");
  }

  find(table: string, id: number): void {
    console.log(`Buscando en la tabla '${table}' el ID ${id} en SQLite`);
  }

  update(table: string, id: number, data: object): void {
    console.log(`Actualizando ID ${id} en la tabla '${table}' con los datos ${JSON.stringify(data)} en SQLite`);
  }

  disconnect(): void {
    console.log("Desconectando de SQLite...");
  }
}
const mysqlDB = new MySQLDatabase();
mysqlDB.connect();
mysqlDB.find("usuarios", 1);
mysqlDB.update("usuarios", 1, { name: "Carlos", age: 30 });
mysqlDB.disconnect();

console.log("-----------");

const sqliteDB = new SQLiteDatabase();
sqliteDB.connect();
sqliteDB.find("productos", 5);
sqliteDB.update("productos", 5, { price: 25.99 });
sqliteDB.disconnect();
