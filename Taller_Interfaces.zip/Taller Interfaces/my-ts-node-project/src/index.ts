interface Vehicule {
  model: string;
  year: number;
  color: string;
}
interface Car extends Vehicule {
  numberOfDoors: number;
  isAutomatic: boolean
}
interface Motorcycle extends Vehicule {
  hasSidecar: boolean;
  engineCapacity: number;
}
const myCar: Car = {
  model: "Toyoya Corolla",
  year: 2020,
  color:"Azul",
  numberOfDoors: 4,
  isAutomatic: true,
};
const myMotorcycle: Motorcycle = {
  model: "Yamaha MT-07",
  year: 2022,
  color: "Negro",
  hasSidecar: false,
  engineCapacity: 689
};

console.log("Mi carro:", myCar);
console.log("Mi moto", myMotorcycle);