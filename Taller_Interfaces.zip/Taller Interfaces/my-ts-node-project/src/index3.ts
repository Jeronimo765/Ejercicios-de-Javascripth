
interface BaseObject {
    id: number;
}
interface User extends BaseObject {
    name: string;
    email: string;
}
interface Product extends BaseObject {
    name: string;
    price: number;
}
interface Order extends BaseObject {
    productId: number;
    userId: number;
    quatity: number;
}
function printObject<T extends BaseObject>(obj: T): void {
    console.log("ID:", obj.id);
    console.log("Detalles:", obj);
}
const user: User = {
    id: 1,
    name: "Ana",
    email: "ana@example.com"
};
const product: Product = {
    id: 101,
    name: "Teclado",
    price: 50
};
const order: Order = {
    id: 1001,
    productId: 101,
    userId: 1,
    quatity: 2
};

printObject(user);
printObject(product);
printObject(order);