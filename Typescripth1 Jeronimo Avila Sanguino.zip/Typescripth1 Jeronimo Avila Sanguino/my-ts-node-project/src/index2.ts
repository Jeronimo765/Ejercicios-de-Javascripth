import * as readline from 'readline';

class SistemaCola {
    private colaClientes: string[] = [];
    private readonly limiteCola: number = 7;

    agregarCliente(nombre: string): void {
        if (this.colaClientes.length >= this.limiteCola) {
            console.log(`La cola está llena. ${nombre} no puede entrar.`);
        } else {
            this.colaClientes.push(nombre);
            console.log(`${nombre} se ha unido a la cola.`);
        }
    }

    atenderCliente(): void {
        if (this.colaClientes.length === 0) {
            console.log("No hay clientes en la cola.");
        } else {
            const clienteAtendido = this.colaClientes.shift();
            console.log(`${clienteAtendido} ha sido atendido.`);
        }
    }

    estadoCola(): void {
        if (this.colaClientes.length === 0) {
            console.log("La cola está vacía.");
        } else {
            console.log(`Hay ${this.colaClientes.length} cliente(s) en la cola: ${this.colaClientes.join(", ")}`);
        }
    }
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const sistemaCola = new SistemaCola();

function mostrarMenu(): void {
    console.log("\n1. Agregar Cliente");
    console.log("2. Atender Cliente");
    console.log("3. Ver Estado de la Cola");
    console.log("4. Salir");

    rl.question("Elige una opción: ", (opcion: string) => {
        switch (opcion) {
            case "1":
                rl.question("Ingrese el nombre del cliente: ", (nombre: string) => {
                    sistemaCola.agregarCliente(nombre);
                    mostrarMenu();
                });
                break;
            case "2":
                sistemaCola.atenderCliente();
                mostrarMenu();
                break;
            case "3":
                sistemaCola.estadoCola();
                mostrarMenu();
                break;
            case "4":
                console.log("Saliendo del sistema...");
                rl.close();
                break;
            default:
                console.log("Opción inválida. Intenta de nuevo.");
                mostrarMenu();
        }
    });
}

mostrarMenu();
