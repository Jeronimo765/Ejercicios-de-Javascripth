import * as readline from 'readline';

class Cajero {
    private saldo: number;
    private transacciones: number[];

    constructor(saldoInicial: number = 1000) {
        this.saldo = saldoInicial;
        this.transacciones = [];
    }

    mostrarSaldo(): void {
        console.log(`Saldo actual: $${this.saldo}`);
    }

    depositarDinero(monto: number): void {
        if (monto <= 0 || isNaN(monto)) {
            console.log("⚠️ Ingresa un monto válido para depositar.");
            return;
        }
        this.saldo += monto;
        this.registrarTransaccion(monto);
        console.log(`✅ Depósito exitoso de $${monto}. Saldo actual: $${this.saldo}`);
    }

    retirarDinero(monto: number): void {
        if (monto > 500) {
            console.log("⚠️ No puedes retirar más de $500 en una sola transacción.");
            return;
        }
        if (monto > this.saldo) {
            console.log("❌ Fondos insuficientes.");
            return;
        }
        this.saldo -= monto;
        this.registrarTransaccion(-monto);
        console.log(`✅ Retiro exitoso de $${monto}. Saldo restante: $${this.saldo}`);
    }

    private registrarTransaccion(monto: number): void {
        this.transacciones.push(monto);
        if (this.transacciones.length > 5) {
            this.transacciones.shift();
        }
    }

    mostrarTransacciones(): void {
        console.log("\n📄 Últimas 5 transacciones:");
        if (this.transacciones.length === 0) {
            console.log("No hay transacciones aún.");
        } else {
            this.transacciones.forEach((trans, index) => {
                const tipo = trans > 0 ? "Depósito" : "Retiro";
                console.log(`${index + 1}. ${tipo}: $${Math.abs(trans)}`);
            });
        }
    }
}

// Crear interfaz de readline
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const cajero = new Cajero();

function preguntar(pregunta: string): Promise<string> {
    return new Promise(resolve => rl.question(pregunta, resolve));
}

async function menu() {
    while (true) {
        const opcion = await preguntar(
            "\n===== CAJERO AUTOMÁTICO =====\n" +
            "1. Ver saldo\n" +
            "2. Depositar dinero\n" +
            "3. Retirar dinero\n" +
            "4. Ver últimas transacciones\n" +
            "5. Salir\n" +
            "Selecciona una opción: "
        );

        switch (opcion) {
            case "1":
                cajero.mostrarSaldo();
                break;
            case "2":
                const dep = await preguntar("Ingresa el monto a depositar: ");
                cajero.depositarDinero(parseFloat(dep));
                break;
            case "3":
                const ret = await preguntar("Ingresa el monto a retirar: ");
                cajero.retirarDinero(parseFloat(ret));
                break;
            case "4":
                cajero.mostrarTransacciones();
                break;
            case "5":
                console.log("Saliendo del cajero...");
                rl.close();
                return;
            default:
                console.log(" Opción inválida. Intenta de nuevo.");
        }
    }
}

menu();
