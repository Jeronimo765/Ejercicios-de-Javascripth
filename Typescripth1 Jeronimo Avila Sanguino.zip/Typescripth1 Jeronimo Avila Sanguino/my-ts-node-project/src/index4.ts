import * as readline from 'readline';

class MaquinaExpendedora {
    private productos: string[];
    private stock: number[];

    constructor() {
        this.productos = ["Galletas", "Chocolatina", "Papas", "Gaseosas", "Caramelos"];
        this.stock = [3, 2, 5, 4, 1];
    }

    mostrarInventario(): void {
        console.log("\n📦 Inventario de la máquina expendedora:");
        this.productos.forEach((producto, index) => {
            console.log(`${index + 1}. ${producto} - stock: ${this.stock[index]}`);
        });
    }

    sugerirProducto(): string | null {
        for (let i = 0; i < this.stock.length; i++) {
            if (this.stock[i] > 0) {
                return this.productos[i];
            }
        }
        return null;
    }

    comprarProducto(codigo: number): void {
        const indice = codigo - 1;

        if (indice < 0 || indice >= this.productos.length) {
            console.log(" Código inválido. Intente de nuevo.");
            return;
        }

        if (this.stock[indice] === 0) {
            console.log(` El producto ${this.productos[indice]} está agotado.`);
            const sugerencia = this.sugerirProducto();
            if (sugerencia) {
                console.log(` Sugerencia: Puedes comprar ${sugerencia} en su lugar.`);
            } else {
                console.log(" La máquina no tiene más productos disponibles.");
            }
            return;
        }

        this.stock[indice]--;
        console.log(` Has comprado ${this.productos[indice]}. ¡Disfrútalo!`);
    }
}


const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const maquina = new MaquinaExpendedora();


function mostrarMenu(): void {
    maquina.mostrarInventario();
    rl.question("\nIngrese el número del producto que desea comprar (o '0' para salir): ", (input: string) => {
        const opcion = parseInt(input);

        if (isNaN(opcion)) {
            console.log(" Entrada no válida. Por favor ingrese un número.");
        } else if (opcion === 0) {
            console.log("Gracias por usar la máquina expendedora. ¡Hasta luego!");
            rl.close();
            return;
        } else {
            maquina.comprarProducto(opcion);
        }

        
        mostrarMenu();
    });
}


mostrarMenu();
