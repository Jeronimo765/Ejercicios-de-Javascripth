import * as readline from 'readline';

type Estado = "Libre" | "Ocupada";

class Hotel2 {
    habitaciones: { [key: number]: Estado };

    constructor() {
        this.habitaciones = {
            1: "Libre",
            2: "Libre",
            3: "Libre",
            4: "Libre",
            5: "Libre"
        };
    }

    mostrarEstado(): void {
        console.log("Estado de habitaciones:");
        for (let num in this.habitaciones) {
            console.log(`Habitación ${num}: ${this.habitaciones[parseInt(num)]}`);
        }
    }

    reservarHabitacion(num: number): void {
        if (!(num in this.habitaciones)) {
            console.log("Número de habitación inválido. Usa 1-5");
        } else if (this.habitaciones[num] === "Ocupada") {
            console.log("Habitación ya ocupada");
        } else {
            this.habitaciones[num] = "Ocupada";
            console.log(`Habitación ${num} reservada con éxito`);
        }
    }

    liberarHabitacion(num: number): void {
        if (!(num in this.habitaciones)) {
            console.log("Número de habitación inválido. Usa 1-5");
        } else if (this.habitaciones[num] === "Libre") {
            console.log("Esta habitación ya está libre");
        } else {
            this.habitaciones[num] = "Libre";
            console.log(`Habitación ${num} liberada con éxito`);
        }
    }
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const hotel = new Hotel2();

function mostrarMenu(): void {
    console.log("\n1. Ver estado\n2. Reservar\n3. Liberar\n4. Salir");
    rl.question("Elige una opción: ", (opcion) => {
        switch (opcion) {
            case "1":
                hotel.mostrarEstado();
                mostrarMenu();
                break;
            case "2":
                rl.question("Ingresa el número de habitación (1-5): ", (input) => {
                    const num = parseInt(input);
                    hotel.reservarHabitacion(num);
                    mostrarMenu();
                });
                break;
            case "3":
                rl.question("Ingresa el número de habitación (1-5): ", (input) => {
                    const num = parseInt(input);
                    hotel.liberarHabitacion(num);
                    mostrarMenu();
                });
                break;
            case "4":
                console.log("Saliendo...");
                rl.close();
                break;
            default:
                console.log("Opción inválida");
                mostrarMenu();
        }
    });
}

mostrarMenu();
